from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

current_option = "NONE"


@app.route("/gaze", methods=["POST"])
def receive_gaze():

    global current_option

    data = request.json

    current_option = data.get("option", "NONE")

    print("Received:", current_option)

    return jsonify({
        "success": True
    })


@app.route("/gaze", methods=["GET"])
def get_gaze():

    return jsonify({
        "option": current_option
    })


if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )