const options = document.querySelectorAll(".option");

let lastSpokenOption = "";


// ---------------------------------------
// SPEECH FUNCTION
// ---------------------------------------

function speakMessage(optionName) {

    let message = "";

    if (optionName === "water") {
        message = "The patient needs water.";
    }

    else if (optionName === "toilet") {
        message = "The patient needs assistance to go to the toilet.";
    }

    else if (optionName === "pain") {
        message = "The patient is in pain.";
    }

    else if (optionName === "help") {
        message = "The patient needs help.";
    }

    if (message !== "") {

        window.speechSynthesis.cancel();

        const speech = new SpeechSynthesisUtterance(message);

        window.speechSynthesis.speak(speech);
    }
}


// ---------------------------------------
// CLICK FUNCTIONALITY
// ---------------------------------------

options.forEach((option) => {

    option.addEventListener("click", () => {

        if (option.classList.contains("water")) {
            speakMessage("water");
        }

        else if (option.classList.contains("toilet")) {
            speakMessage("toilet");
        }

        else if (option.classList.contains("pain")) {
            speakMessage("pain");
        }

        else if (option.classList.contains("help")) {
            speakMessage("help");
        }

    });

});


// ---------------------------------------
// EYE GAZE TRACKING
// ---------------------------------------

async function checkGaze() {

    try {

        const response = await fetch(
            "http://127.0.0.1:5000/gaze"
        );

        const data = await response.json();

        const lookingAt = data.option.toLowerCase();


        // Remove glow from all options

        options.forEach((option) => {
            option.classList.remove("gaze-active");
        });


        // Add glow to current option

        const activeOption = document.querySelector(
            "." + lookingAt
        );

        if (activeOption) {

            activeOption.classList.add("gaze-active");

        }


        // ---------------------------------------
        // SPEAK WHEN GAZE CHANGES
        // ---------------------------------------

        if (
            lookingAt !== lastSpokenOption &&
            lookingAt !== "none"
        ) {

            console.log("Speaking:", lookingAt);

            speakMessage(lookingAt);

            lastSpokenOption = lookingAt;

        }

    }

    catch (error) {

        console.log("Eye tracking server not connected");

    }

}


// Check every 200 milliseconds

setInterval(checkGaze, 200);